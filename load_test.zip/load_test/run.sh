#!/bin/bash
# 빠른 실행 스크립트

# 파일 디스크립터 제한 증가
ulimit -n 65535 2>/dev/null || echo "⚠️  ulimit 설정 실패 (권한 필요)"

echo "🔥 부하 테스트 실행..."
python3 load_test.py
